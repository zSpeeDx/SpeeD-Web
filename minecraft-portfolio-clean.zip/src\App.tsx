import { AppProvider, useApp } from "@/app/AppProvider";
import { BackToTop } from "@/components/BackToTop";
import { Footer } from "@/components/Footer";
import { Loader } from "@/components/Loader";
import { Navbar } from "@/components/Navbar";
import { PointerFX } from "@/components/PointerFX";
import { SiteBackground } from "@/components/SiteBackground";
import { TechMarquee } from "@/components/TechMarquee";
import { About } from "@/components/sections/About";
import { Contact } from "@/components/sections/Contact";
import { Experience } from "@/components/sections/Experience";
import { Hero } from "@/components/sections/Hero";
import { Projects } from "@/components/sections/Projects";
import { Servers } from "@/components/sections/Servers";

function Portfolio() {
  const { t } = useApp();

  return (
    <div className="relative min-h-screen overflow-x-clip">
      <Loader />
      <a
        href="#main"
        className="fixed start-4 top-4 z-[210] -translate-y-24 bg-accent px-4 py-2 text-sm font-semibold text-[var(--c-on)] transition-transform focus:translate-y-0"
      >
        {t.nav.skip}
      </a>

      <SiteBackground />
      <PointerFX />
      <Navbar />

      <main id="main" className="relative z-10">
        <Hero />
        <TechMarquee />
        <About />
        <Projects />
        <Servers />
        <Experience />
        <Contact />
      </main>

      <Footer />
      <BackToTop />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Portfolio />
    </AppProvider>
  );
}
