import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { translations, type Lang, type Translation } from "@/i18n/translations";
import {
  applyTheme,
  CUSTOM_THEME_ID,
  DEFAULT_THEME,
  getTheme,
  makeCustomTheme,
  normalizeHex,
  type Theme,
} from "@/theme/themes";

const LANG_KEY = "zspeedx:lang";
const THEME_KEY = "zspeedx:theme";
const CUSTOM_KEY = "zspeedx:custom-color";

type AppContextValue = {
  lang: Lang;
  setLang: (lang: Lang) => void;
  toggleLang: () => void;
  theme: Theme;
  setTheme: (id: string) => void;
  setCustomColor: (hex: string) => boolean;
  customHex: string;
  t: Translation;
  isRTL: boolean;
  dirSign: 1 | -1;
};

const AppContext = createContext<AppContextValue | null>(null);

function readLang(): Lang {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === "ar" || saved === "en") return saved;
  } catch {
    /* storage may be unavailable */
  }
  return "en";
}

function readTheme(): string {
  try {
    return localStorage.getItem(THEME_KEY) ?? DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}

function readCustomColor(): string {
  try {
    return normalizeHex(localStorage.getItem(CUSTOM_KEY) ?? "") ?? "#ff0040";
  } catch {
    return "#ff0040";
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(readLang);
  const [themeId, setThemeId] = useState<string>(readTheme);
  const [customHex, setCustomHex] = useState<string>(readCustomColor);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    try {
      localStorage.setItem(LANG_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  const toggleLang = useCallback(() => {
    setLang(lang === "en" ? "ar" : "en");
  }, [lang, setLang]);

  const setTheme = useCallback((id: string) => {
    setThemeId(id);
    try {
      localStorage.setItem(THEME_KEY, id);
    } catch {
      /* ignore */
    }
  }, []);

  const setCustomColor = useCallback((value: string) => {
    const hex = normalizeHex(value);
    if (!hex) return false;
    setCustomHex(hex);
    setThemeId(CUSTOM_THEME_ID);
    try {
      localStorage.setItem(CUSTOM_KEY, hex);
      localStorage.setItem(THEME_KEY, CUSTOM_THEME_ID);
    } catch {
      /* ignore */
    }
    return true;
  }, []);

  const theme = useMemo(
    () => (themeId === CUSTOM_THEME_ID ? makeCustomTheme(customHex) : getTheme(themeId)),
    [themeId, customHex],
  );
  const t = translations[lang];
  const isRTL = lang === "ar";

  useLayoutEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useLayoutEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    root.dir = isRTL ? "rtl" : "ltr";
  }, [lang, isRTL]);

  useEffect(() => {
    document.title = isRTL
      ? "Dev zSpeeDx — مطوّر ماينكرافت فل ستاك"
      : "Dev zSpeeDx — Minecraft Fullstack Developer";
    const desc = document.querySelector('meta[name="description"]');
    if (desc) {
      desc.setAttribute(
        "content",
        isRTL
          ? "Dev zSpeeDx مطوّر ماينكرافت فل ستاك — أنظمة مخصّصة، رتب وصلاحيات، NPCs وهولوغرام، Survival وBoxPvP وSMP وDuels، تحسين أداء، وتجهيز مجتمع كامل. أكثر من 3 سنوات، و50+ سيرفر، و11 مشروعاً. استكشف المشاريع وتواصل عبر ديسكورد."
          : "Dev zSpeeDx is a Minecraft Fullstack Developer building complete servers: custom systems, ranks & permissions, NPCs & holograms, Survival / BoxPvP / SMP / Duels, performance optimization and full community setups. 3+ years, 50+ servers, and 11 projects built. Explore the work and get in touch on Discord.",
      );
    }
  }, [lang, isRTL]);

  const value = useMemo<AppContextValue>(
    () => ({
      lang,
      setLang,
      toggleLang,
      theme,
      setTheme,
      setCustomColor,
      customHex,
      t,
      isRTL,
      dirSign: isRTL ? -1 : 1,
    }),
    [lang, setLang, toggleLang, theme, setTheme, setCustomColor, customHex, t, isRTL],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
