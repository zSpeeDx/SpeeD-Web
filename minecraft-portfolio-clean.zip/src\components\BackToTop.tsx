import { AnimatePresence, motion } from "motion/react";
import { ArrowUp } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { useScrolled } from "@/hooks/useInView";

export function BackToTop() {
  const { t } = useApp();
  const show = useScrolled(700);

  return (
    <AnimatePresence>
      {show ? (
        <motion.button
          type="button"
          className="back-top"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label={t.common.backToTop}
          title={t.common.backToTop}
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.85 }}
          transition={{ duration: 0.18 }}
        >
          <ArrowUp className="h-4 w-4" strokeWidth={2.4} />
        </motion.button>
      ) : null}
    </AnimatePresence>
  );
}
