import { ArrowUp, ArrowUpRight, ShieldCheck } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { Brand } from "@/components/ui/Brand";
import { DiscordIcon } from "@/components/ui/DiscordIcon";
import { PixelCube } from "@/components/ui/PixelCube";
import { PROFILE } from "@/data/projects";

export function Footer() {
  const { t, lang } = useApp();
  const year = new Date().getFullYear();

  const links = [
    { id: "home", label: t.nav.home },
    { id: "about", label: t.nav.about },
    { id: "projects", label: t.nav.projects },
    { id: "servers", label: t.nav.servers },
    { id: "experience", label: t.nav.experience },
    { id: "contact", label: t.nav.contact },
  ];

  return (
    <footer className="footer relative z-10 overflow-hidden">
      <div
        className="pointer-events-none absolute -bottom-8 start-1/2 w-full -translate-x-1/2 select-none whitespace-nowrap text-center font-mono text-[clamp(3.4rem,13vw,10.5rem)] font-bold leading-none tracking-tighter text-white/[0.028] rtl:translate-x-1/2"
        aria-hidden="true"
        dir="ltr"
      >
        zSpeeDx
      </div>

      <div className="container-x relative pt-12 pb-6">
        <div className="grid gap-8 border-b border-line pb-9 sm:grid-cols-2 lg:grid-cols-[1.4fr_0.7fr_1fr]">
          <div>
            <Brand />
            <p className="mt-4 max-w-xs text-[11.5px] leading-[1.85] text-muted">{t.footer.tagline}</p>
            <div className="mt-4 flex items-center gap-2">
              <span className="status-chip">
                <span className="status-dot" />
                {t.common.available}
              </span>
              <PixelCube size={20} className="hidden opacity-50 sm:block" />
            </div>
          </div>

          <div>
            <h3 className="meta-label">{t.footer.navTitle}</h3>
            <ul className="mt-3 grid gap-2">
              {links.map((link) => (
                <li key={link.id}>
                  <a href={`#${link.id}`} className="footer-link inline-flex items-center gap-1.5">
                    <span className="h-1 w-1 bg-accent/60" aria-hidden="true" />
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="meta-label">{t.footer.connectTitle}</h3>
            <p className="mt-3 max-w-xs text-[11px] leading-relaxed text-muted">{t.footer.connectDesc}</p>
            <a
              href={PROFILE.discordUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="panel mt-3 flex items-center gap-2.5 p-2.5 transition-colors hover:border-accent-line hover:bg-accent-soft"
            >
              <span className="mc-slot h-8 w-8 shrink-0 text-accent">
                <DiscordIcon className="h-4 w-4" />
              </span>
              <span className="min-w-0">
                <span className="block truncate text-[11.5px] font-medium text-ink">Dev zSpeeDx</span>
                <span className="block truncate font-mono text-[8.5px] text-muted" dir="ltr">
                  {PROFILE.discordId}
                </span>
              </span>
              <ArrowUpRight className="ms-auto h-3.5 w-3.5 shrink-0 text-muted rtl:-scale-x-100" />
            </a>
            <p className="mt-2 flex items-center gap-1.5 text-[9.5px] text-muted/60">
              <ShieldCheck className="h-3 w-3" />
              {t.common.officialContact}
            </p>
          </div>
        </div>

        <div className="flex flex-col items-start justify-between gap-3 pt-5 sm:flex-row sm:items-center">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-muted/70">
            <span className="latin">© {year}</span>
            <span>{t.footer.rights}</span>
            <span className="hidden h-1 w-1 bg-accent sm:block" aria-hidden="true" />
            <span className="flex items-center gap-1.5">
              <PixelCube size={11} className="opacity-80" />
              {t.footer.built}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-muted/45">
              {lang === "ar" ? "النسخة 1.0" : "version 1.0"}
            </span>
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="ring-dot"
              aria-label={t.footer.top}
              title={t.footer.top}
            >
              <ArrowUp className="relative h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
