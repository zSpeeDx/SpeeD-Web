import { useEffect, useState, type FormEvent } from "react";
import { Check, Pipette, Sparkles } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { normalizeHex } from "@/theme/themes";

/**
 * Free-form colour picker: native picker + editable #RRGGBB field.
 * Applies to every theme token immediately and persists in localStorage.
 */
export function HexColorField({ onApplied }: { onApplied?: () => void }) {
  const { t, theme, customHex, setCustomColor } = useApp();
  const [draft, setDraft] = useState(theme.hex.toUpperCase());
  const [error, setError] = useState(false);
  const [applied, setApplied] = useState(false);

  // Keep the field in sync with external changes (presets, reset).
  useEffect(() => {
    setDraft(theme.hex.toUpperCase());
  }, [theme.hex]);

  useEffect(() => {
    if (!applied) return;
    const timer = window.setTimeout(() => setApplied(false), 1800);
    return () => window.clearTimeout(timer);
  }, [applied]);

  const apply = (value: string) => {
    const hex = normalizeHex(value);
    if (!hex) {
      setError(true);
      return false;
    }
    setError(false);
    setCustomColor(hex);
    setDraft(hex.toUpperCase());
    setApplied(true);
    onApplied?.();
    return true;
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    apply(draft);
  };

  return (
    <div className="hex-picker">
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-ink">
          <Sparkles className="h-3 w-3 text-accent" />
          {t.theme.customTitle}
        </p>
        <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-muted/60">
          HEX / RGB
        </span>
      </div>

      <form onSubmit={submit} className="mt-2 flex items-stretch gap-1.5">
        <label className="hex-native" title={t.theme.customTitle} style={{ background: normalizeHex(draft) ?? customHex }}>
          <input
            type="color"
            value={normalizeHex(draft) ?? customHex}
            onChange={(event) => {
              setDraft(event.target.value.toUpperCase());
              apply(event.target.value);
            }}
            aria-label={t.theme.customTitle}
          />
          <Pipette className="pointer-events-none relative h-3.5 w-3.5 drop-shadow-[0_1px_2px_rgba(0,0,0,.65)]" />
        </label>

        <input
          value={draft}
          onChange={(event) => {
            setDraft(event.target.value.toUpperCase().slice(0, 7));
            setError(false);
          }}
          onBlur={() => {
            if (normalizeHex(draft)) apply(draft);
          }}
          placeholder="#FF0040"
          aria-label={t.theme.hexLabel}
          aria-invalid={error}
          spellCheck={false}
          autoComplete="off"
          inputMode="text"
          dir="ltr"
          className="hex-input"
        />

        <button type="submit" className="hex-apply" aria-label={t.theme.apply} title={t.theme.apply}>
          {applied ? <Check className="h-3.5 w-3.5" /> : t.theme.apply}
        </button>
      </form>

      <div className="mt-1.5 flex items-start justify-between gap-2">
        <p className={`hex-hint ${error ? "text-red-400" : "text-muted/65"}`}>
          {error ? t.theme.invalid : t.theme.customDesc}
        </p>
        <span
          className="mt-0.5 h-3 w-3 shrink-0 rounded-[1px] border border-white/25"
          style={{ background: normalizeHex(draft) ?? customHex }}
          aria-hidden="true"
        />
      </div>
      <span className="sr-only" role="status" aria-live="polite">
        {applied ? t.theme.applied : ""}
      </span>
    </div>
  );
}
