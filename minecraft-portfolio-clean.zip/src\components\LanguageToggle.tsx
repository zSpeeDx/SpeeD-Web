import { useApp } from "@/app/AppProvider";
import { cn } from "@/utils/cn";

export function LanguageToggle({ className }: { className?: string }) {
  const { lang, setLang, t } = useApp();
  return (
    <div
      role="group"
      aria-label={t.nav.language}
      className={cn(
        "inline-flex items-center gap-0.5 rounded-[3px] border border-line bg-white/[0.035] p-0.5",
        className,
      )}
    >
      <button
        type="button"
        onClick={() => setLang("en")}
        aria-pressed={lang === "en"}
        aria-label="English"
        className={cn(
          "rounded-[1px] px-2 py-[5px] font-mono text-[10px] font-medium tracking-[0.08em] transition-all duration-200",
          lang === "en"
            ? "bg-accent text-[var(--c-on)] shadow-[inset_0_1px_0_rgba(255,255,255,.25)]"
            : "text-muted hover:bg-white/5 hover:text-ink",
        )}
      >
        EN
      </button>
      <button
        type="button"
        onClick={() => setLang("ar")}
        aria-pressed={lang === "ar"}
        aria-label="العربية"
        className={cn(
          "rounded-[1px] px-2 py-[5px] text-[10px] font-medium transition-all duration-200",
          lang === "ar"
            ? "bg-accent text-[var(--c-on)] shadow-[inset_0_1px_0_rgba(255,255,255,.25)]"
            : "text-muted hover:bg-white/5 hover:text-ink",
        )}
      >
        عربي
      </button>
    </div>
  );
}
