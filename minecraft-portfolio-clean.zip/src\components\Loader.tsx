import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useApp } from "@/app/AppProvider";

export function Loader() {
  const { t } = useApp();
  const reduced = useReducedMotion();
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (reduced) {
      setVisible(false);
      return;
    }
    const timer = window.setTimeout(() => setVisible(false), 600);
    return () => window.clearTimeout(timer);
  }, [reduced]);

  useEffect(() => {
    if (!visible) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [visible]);

  return (
    <AnimatePresence>
      {visible ? (
        <motion.div
          className="loader-screen"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.45, ease: "easeInOut" }}
          role="status"
          aria-live="polite"
        >
          <div className="flex flex-col items-center gap-6 px-6 text-center">
            <div className="flex items-center gap-3">
              <span className="grid grid-cols-2 gap-[3px]" aria-hidden="true">
                <span className="h-4 w-4 border border-ink/30 bg-accent shadow-[inset_0_2px_0_rgba(255,255,255,.35)]" />
                <span className="h-4 w-4 border border-ink/30 bg-accent/40" />
                <span className="h-4 w-4 border border-ink/30 bg-accent/70" />
                <span className="h-4 w-4 border border-ink/30 bg-accent shadow-[inset_0_2px_0_rgba(255,255,255,.35)]" />
              </span>
              <span className="text-lg font-bold tracking-tight">
                Dev <span className="text-accent">zSpeeDx</span>
              </span>
            </div>
            <div className="loader-blocks" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
            </div>
            <div className="space-y-2">
              <p className="font-pixel text-[9px] uppercase tracking-[0.16em] text-ink">{t.common.loading}…</p>
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">{t.common.loadingSub}</p>
            </div>
            <div className="loader-bar" aria-hidden="true">
              <i />
            </div>
          </div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
