import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { LanguageToggle } from "@/components/LanguageToggle";
import { ThemeSelector } from "@/components/ThemeSelector";
import { Brand } from "@/components/ui/Brand";
import { Button } from "@/components/ui/Button";
import { useActiveSection, useScrolled } from "@/hooks/useInView";
import { cn } from "@/utils/cn";

const NAV_IDS: string[] = ["home", "about", "projects", "servers", "experience", "contact"];

export function Navbar() {
  const { t } = useApp();
  const scrolled = useScrolled(16);
  const active = useActiveSection(NAV_IDS);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMobileOpen(false);
    };
    const onResize = () => {
      if (window.innerWidth >= 1280) setMobileOpen(false);
    };
    document.addEventListener("keydown", onKey);
    window.addEventListener("resize", onResize);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onResize);
    };
  }, [mobileOpen]);

  const links = [
    { id: "home", label: t.nav.home },
    { id: "about", label: t.nav.about },
    { id: "projects", label: t.nav.projects },
    { id: "servers", label: t.nav.servers },
    { id: "experience", label: t.nav.experience },
    { id: "contact", label: t.nav.contact },
  ];

  // Scroll is locked while the mobile menu is open, so release it first.
  const goToSection = (id: string) => {
    setMobileOpen(false);
    window.setTimeout(() => {
      document.getElementById(id)?.scrollIntoView({
        behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      });
      window.history.replaceState(null, "", `#${id}`);
    }, 140);
  };

  return (
    <header className={cn("nav-shell", (scrolled || mobileOpen) && "is-scrolled")}>
      <div className="scroll-progress" aria-hidden="true" />
      <div className="container-x">
        <div className="flex h-[72px] items-center justify-between gap-3">
          <Brand onClick={() => setMobileOpen(false)} />

          <nav className="hidden items-center gap-6 xl:flex" aria-label="Primary">
            {links.map((link) => (
              <a key={link.id} href={`#${link.id}`} className="nav-link" data-active={active === link.id}>
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <LanguageToggle />
            <div className="hidden sm:block">
              <ThemeSelector />
            </div>
            <Button href="#contact" size="sm" className="hidden xl:inline-flex">
              {t.nav.talk}
              <ArrowUpRight className="h-3.5 w-3.5 rtl:-scale-x-100" />
            </Button>
            <button
              type="button"
              className="btn-icon h-9 w-9 xl:!hidden"
              onClick={() => setMobileOpen((open) => !open)}
              aria-expanded={mobileOpen}
              aria-controls="mobile-nav"
              aria-label={mobileOpen ? t.nav.close : t.nav.menu}
            >
              {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen ? (
          <motion.div
            aria-hidden="true"
            key="mobile-scrim"
            className="fixed inset-x-0 top-[72px] bottom-0 z-[-1] bg-[#04050a]/95 xl:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={() => setMobileOpen(false)}
          />
        ) : null}
        {mobileOpen ? (
          <motion.div
            id="mobile-nav"
            key="mobile-nav"
            className="mobile-menu relative z-10 overflow-hidden xl:hidden"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="container-x max-h-[calc(100dvh-72px)] overflow-y-auto py-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="status-chip">
                  <span className="status-dot" />
                  {t.common.available}
                </span>
                <span className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-muted/50">
                  zSpeeDx v1.1
                </span>
              </div>

              <nav className="mt-3 flex flex-col" aria-label="Mobile">
                {links.map((link, index) => (
                  <a
                    key={link.id}
                    href={`#${link.id}`}
                    onClick={(event) => {
                      event.preventDefault();
                      goToSection(link.id);
                    }}
                    className="group flex items-center justify-between border-b border-line py-3.5 transition-colors"
                  >
                    <span className="flex items-baseline gap-3">
                      <span className="font-mono text-[9px] tracking-[0.1em] text-accent/70">
                        0{index + 1}
                      </span>
                      <span
                        className={cn(
                          "text-[15px] font-medium",
                          active === link.id ? "text-ink" : "text-muted group-hover:text-ink",
                        )}
                      >
                        {link.label}
                      </span>
                    </span>
                    <ArrowUpRight
                      className="h-4 w-4 text-muted transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:text-accent rtl:-scale-x-100"
                      strokeWidth={1.7}
                    />
                  </a>
                ))}
              </nav>

              <div className="mt-5">
                <ThemeSelector inline />
              </div>

              <Button
                href="#contact"
                className="mt-4 w-full"
                onClick={(event) => {
                  event.preventDefault();
                  goToSection("contact");
                }}
              >
                {t.nav.talk}
                <ArrowUpRight className="h-4 w-4 rtl:-scale-x-100" />
              </Button>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
