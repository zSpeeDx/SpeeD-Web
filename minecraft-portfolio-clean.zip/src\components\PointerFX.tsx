import { useEffect, useRef } from "react";

/**
 * A single compositor-friendly pointer layer: one glow element, one reticle and
 * a tiny parallax value for the decorative blocks. Everything is driven by one
 * rAF batch and only while the user is actually moving a fine pointer.
 */
export function PointerFX() {
  const glowRef = useRef<HTMLDivElement>(null);
  const cursorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduced) return;

    const glow = glowRef.current;
    const cursor = cursorRef.current;
    const scene = document.querySelector<HTMLElement>(".site-bg");
    const root = document.documentElement;
    let x = window.innerWidth / 2;
    let y = window.innerHeight / 2;
    let frame = 0;
    let visible = false;

    const render = () => {
      frame = 0;
      const transform = `translate3d(${x}px, ${y}px, 0)`;
      if (glow) glow.style.transform = transform;
      if (cursor) cursor.style.transform = transform;
      if (scene) {
        scene.style.setProperty("--pnx", `${(x / window.innerWidth - 0.5).toFixed(3)}`);
        scene.style.setProperty("--pny", `${(y / window.innerHeight - 0.5).toFixed(3)}`);
      }
    };

    const show = () => {
      if (visible) return;
      visible = true;
      root.classList.add("pointer-fx-on");
    };

    const onMove = (event: PointerEvent) => {
      show();
      x = event.clientX;
      y = event.clientY;
      if (!frame) frame = requestAnimationFrame(render);
    };

    // Event delegation: toggle the reticle state without touching React state.
    const onOver = (event: PointerEvent) => {
      const target = event.target as Element | null;
      const hot = Boolean(
        target?.closest("a, button, input, textarea, select, [data-interactive]"),
      );
      cursor?.classList.toggle("is-hot", hot);
    };

    const onLeave = () => {
      visible = false;
      root.classList.remove("pointer-fx-on");
    };

    document.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerover", onOver, { passive: true });
    document.addEventListener("pointerleave", onLeave);
    render();

    return () => {
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerover", onOver);
      document.removeEventListener("pointerleave", onLeave);
      root.classList.remove("pointer-fx-on");
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <>
      <div ref={glowRef} className="mc-glow" aria-hidden="true" />
      <div ref={cursorRef} className="mc-cursor" aria-hidden="true" />
    </>
  );
}
