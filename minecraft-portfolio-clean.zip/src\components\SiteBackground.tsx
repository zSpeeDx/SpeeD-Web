import type { CSSProperties } from "react";
import { PixelCube } from "@/components/ui/PixelCube";

type BlockSpec = {
  top: string;
  left?: string;
  right?: string;
  size: number;
  opacity: number;
  duration: string;
  delay: string;
  drift: string;
  rotate: string;
  hideMobile?: boolean;
  depth: number;
};

/** A small set of CSS-only decorative blocks — no pointer listeners, no filters. */
const BLOCKS: BlockSpec[] = [
  { top: "14%", left: "5%", size: 24, opacity: 0.3, duration: "24s", delay: "-2s", drift: "12px", rotate: "10deg", hideMobile: true, depth: 18 },
  { top: "30%", right: "6%", size: 32, opacity: 0.22, duration: "28s", delay: "-8s", drift: "-16px", rotate: "-8deg", depth: 26 },
  { top: "64%", left: "9%", size: 20, opacity: 0.22, duration: "22s", delay: "-5s", drift: "10px", rotate: "16deg", depth: 12 },
  { top: "80%", right: "16%", size: 28, opacity: 0.14, duration: "30s", delay: "-12s", drift: "-12px", rotate: "-14deg", hideMobile: true, depth: 34 },
];

export function SiteBackground() {
  return (
    <div className="site-bg" aria-hidden="true">
      {BLOCKS.map((block, index) => (
        <div
          key={index}
          className={`floating-block ${block.hideMobile ? "hidden sm:block" : ""}`}
          style={
            {
              top: block.top,
              left: block.left,
              right: block.right,
              opacity: block.opacity,
              "--dur": block.duration,
              "--delay": block.delay,
              "--dx": block.drift,
              "--rot": block.rotate,
              "--depth": `${block.depth}px`,
            } as CSSProperties
          }
        >
          <PixelCube size={block.size} />
        </div>
      ))}
      <span className="hero-crosshair" style={{ top: "18%", insetInlineEnd: "18%" }} />
      <span className="hero-crosshair" style={{ top: "74%", insetInlineStart: "8%" }} />
      <span className="absolute bottom-8 left-8 hidden font-mono text-[9px] uppercase tracking-[0.3em] text-white/15 lg:block">
        // OVERWORLD · SECTOR 011
      </span>
      <span
        className="absolute top-1/2 right-4 hidden -translate-y-1/2 rotate-90 font-mono text-[9px] uppercase tracking-[0.34em] text-white/15 lg:block"
        dir="ltr"
      >
        X 050 · Y 003 · Z 011
      </span>
    </div>
  );
}
