import { useApp } from "@/app/AppProvider";
import { PixelCube } from "@/components/ui/PixelCube";

export function TechMarquee() {
  const { t } = useApp();
  const items = [...t.marquee, ...t.marquee];

  return (
    <div className="marquee relative z-10" aria-hidden="true">
      <div className="marquee-track">
        {items.map((item, index) => (
          <span className="marquee-item" key={`${item}-${index}`}>
            {index % 4 === 0 ? (
              <PixelCube size={9} className="shrink-0 opacity-70" />
            ) : null}
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
