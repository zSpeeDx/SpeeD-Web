import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Check, ChevronDown, Palette, RotateCcw } from "lucide-react";
import { HexColorField } from "@/components/HexColorField";
import { useApp } from "@/app/AppProvider";
import { THEMES } from "@/theme/themes";
import { cn } from "@/utils/cn";

function isLight(hex: string) {
  const clean = hex.replace("#", "");
  const n = Number.parseInt(clean, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.62;
}

export function ThemeSelector({
  inline = false,
  onSelect,
}: {
  inline?: boolean;
  onSelect?: () => void;
}) {
  const { theme, setTheme, setCustomColor, t, lang } = useApp();
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (event: PointerEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(event.target as Node)) setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const choose = (id: string) => {
    setTheme(id);
    onSelect?.();
    if (!inline) setOpen(false);
  };

  const grid = (
    <div className="grid grid-cols-7 gap-2" role="group" aria-label={t.theme.presets}>
      {THEMES.map((item) => {
        const active = item.id === theme.id;
        return (
          <button
            key={item.id}
            type="button"
            className="swatch"
            style={{ backgroundColor: item.hex }}
            data-active={active}
            onClick={() => choose(item.id)}
            aria-label={`${item.name[lang]}${active ? ` — ${t.a11y.themeSelected}` : ""}`}
            aria-pressed={active}
            title={item.name[lang]}
          >
            {active ? (
              <Check
                className="h-3.5 w-3.5"
                strokeWidth={3}
                style={{ color: isLight(item.hex) ? "#0b0c0f" : "#ffffff" }}
              />
            ) : null}
          </button>
        );
      })}
    </div>
  );

  const meta = (
    <div className="flex items-center justify-between gap-2">
      <div>
        <p className="text-[12px] font-semibold text-ink">{t.theme.title}</p>
        <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.12em] text-muted">
          {theme.name[lang]} · {theme.hex}
        </p>
      </div>
      <span
        className="h-7 w-7 rounded-[2px] border border-white/20 shadow-[inset_0_2px_0_rgba(255,255,255,.3)]"
        style={{ backgroundColor: theme.hex }}
        aria-hidden="true"
      />
    </div>
  );

  if (inline) {
    return (
      <div className="panel p-3.5">
        {meta}
        <div className="mt-3">{grid}</div>
        <div className="mt-3 border-t border-line pt-3">
          <HexColorField />
        </div>
        <p className="mt-3 text-[10.5px] leading-relaxed text-muted">{t.theme.desc}</p>
      </div>
    );
  }

  return (
    <div className="relative" ref={wrapRef}>
      <button
        type="button"
        className={cn(
          "relative inline-flex h-9 items-center gap-2 rounded-[3px] border border-line bg-white/[0.03] px-2 text-muted transition-all duration-200 hover:border-accent-line hover:bg-accent-soft hover:text-ink",
          open && "border-accent-line bg-accent-soft text-ink",
        )}
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-label={`${t.nav.theme}: ${theme.name[lang]}`}
        title={t.nav.themeHint}
      >
        <Palette className="h-[15px] w-[15px]" strokeWidth={1.8} />
        <span
          className="h-3.5 w-3.5 rounded-[1px] border border-white/25 shadow-[inset_0_1px_0_rgba(255,255,255,.35)]"
          style={{ backgroundColor: theme.hex }}
          aria-hidden="true"
        />
        <ChevronDown
          className={cn("h-3 w-3 transition-transform duration-200", open && "rotate-180")}
          strokeWidth={2}
        />
      </button>

      <AnimatePresence>
        {open ? (
          <motion.div
            className="theme-pop"
            role="dialog"
            aria-label={t.theme.title}
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
          >
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent to-transparent" />
            {meta}
            <div className="mt-3">{grid}</div>
            <div className="mt-3 border-t border-line pt-3">
              <HexColorField onApplied={() => null} />
            </div>
            <p className="mt-3 text-[10.5px] leading-relaxed text-muted">{t.theme.desc}</p>
            <div className="mt-3 flex items-center justify-between border-t border-line pt-2.5">
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-muted">
                {THEMES.length} themes
              </span>
              <button
                type="button"
                onClick={() => {
                  setCustomColor("#ff0040");
                  choose("red");
                }}
                className="inline-flex items-center gap-1 text-[10px] text-muted transition-colors hover:text-accent"
              >
                <RotateCcw className="h-3 w-3" />
                {t.theme.reset}
              </button>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
