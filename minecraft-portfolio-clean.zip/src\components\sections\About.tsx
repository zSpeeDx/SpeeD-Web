import {
  Blocks,
  Gauge,
  ScanFace,
  ShieldCheck,
  Swords,
  Terminal,
  Users,
  type LucideIcon,
} from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { AnimatedNumber } from "@/components/ui/AnimatedNumber";
import { PixelCube } from "@/components/ui/PixelCube";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { useInView } from "@/hooks/useInView";
import { PROFILE } from "@/data/projects";

const SKILL_ICONS: LucideIcon[] = [Blocks, ShieldCheck, ScanFace, Swords, Gauge, Users];

export function About() {
  const { t } = useApp();
  const { ref: statsRef, inView } = useInView<HTMLDivElement>({ threshold: 0.35 });

  const infoRows = [
    { label: t.about.infoLabels.name, value: PROFILE.name },
    { label: t.about.infoLabels.role, value: t.hero.cardRole },
    { label: t.about.infoLabels.experience, value: t.hero.xpValue },
    { label: t.about.infoLabels.projects, value: "11" },
    { label: t.about.infoLabels.servers, value: `50+` },
  ];

  return (
    <section id="about" className="section section-anchor relative">
      <div className="container-x">
        <SectionHeading
          kicker={t.about.kicker}
          title={t.about.title}
          description={t.about.description2}
        />

        <div className="mt-11 grid items-start gap-4 lg:mt-14 lg:grid-cols-[1.02fr_0.98fr] lg:gap-5">
          {/* left column */}
          <div className="space-y-4">
            <Reveal y={18}>
              <div className="panel accent-frame relative overflow-hidden p-5 sm:p-6">
                <div className="pointer-events-none absolute -end-10 -top-10 opacity-[0.08]">
                  <PixelCube size={120} />
                </div>

                <div className="relative flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="mc-slot h-14 w-14 overflow-hidden">
                      <img
                        src={PROFILE.avatar}
                                          onError={(event) => {
                                            const img = event.currentTarget;
                                            if (img.dataset.avatarFallback) return;
                                            img.dataset.avatarFallback = "true";
                                            img.src =
                                              "data:image/svg+xml;utf8," +
                                              encodeURIComponent(
                                                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e94b5c"/><stop offset="1" stop-color="#9c1024"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><path d="M160 150h192v58L230 306h122v58H160v-58l122-98H160z" fill="#fff"/></svg>',
                                              );
                                          }}
                        alt={t.hero.imageAlt}
                        className="h-full w-full object-contain p-1"
                        loading="lazy"
                        width={56}
                        height={56}
                      />
                    </div>
                    <div>
                      <p className="meta-label">{t.about.profileTitle}</p>
                      <h3 className="mt-1 text-lg font-semibold tracking-tight text-ink">
                        {PROFILE.name}
                      </h3>
                      <p className="mt-0.5 text-[11px] text-accent">{t.hero.cardRole}</p>
                    </div>
                  </div>
                  <span className="mc-slot h-9 w-9 shrink-0 text-accent">
                    <Terminal className="h-4 w-4" strokeWidth={1.7} />
                  </span>
                </div>

                <p className="relative mt-5 text-[13px] leading-[1.9] text-muted">{t.about.description}</p>

                <div className="relative mt-4">
                  {infoRows.map((row) => (
                    <div className="info-row" key={row.label}>
                      <span className="meta-label self-center">{row.label}</span>
                      <span className="text-[12.5px] font-medium text-ink/90 sm:text-end">{row.value}</span>
                    </div>
                  ))}
                </div>

                <div className="relative mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-4">
                  <span className="status-chip">
                    <span className="status-dot" />
                    {t.about.availability}
                  </span>
                  <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted/70" dir="ltr">
                    ID // {PROFILE.discordId.slice(0, 6)}···{PROFILE.discordId.slice(-4)}
                  </span>
                </div>
              </div>
            </Reveal>

            <div ref={statsRef} className="grid gap-3 sm:grid-cols-3">
              {t.about.stats.map((stat, index) => (
                <Reveal key={stat.label} delay={index * 0.08} y={18}>
                  <div className="stat-card h-full p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-muted/60">
                        0{index + 1}
                      </span>
                      <span className="h-1.5 w-1.5 bg-accent shadow-[0_0_8px_var(--c-glow)]" />
                    </div>
                    <div className="mt-3 flex items-end gap-1">
                      <AnimatedNumber
                        value={stat.value}
                        suffix={stat.suffix}
                        active={inView}
                        className="stat-value text-[2rem] leading-none"
                        duration={1400 + index * 180}
                      />
                    </div>
                    <p className="mt-2 text-[11.5px] font-medium leading-snug text-ink/85">{stat.label}</p>
                    <p className="mt-1 text-[10px] leading-snug text-muted/75">{stat.note}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          {/* right column */}
          <div className="space-y-4">
            <Reveal y={18} delay={0.05}>
              <div className="panel p-5 sm:p-6">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-sm font-semibold tracking-tight text-ink">{t.about.skillsTitle}</h3>
                  <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-muted">6.0</span>
                </div>
                <div className="mt-2">
                  {t.about.skills.map((skill, index) => {
                    const Icon = SKILL_ICONS[index] ?? Blocks;
                    return (
                      <div
                        key={skill.title}
                        className="skill-row group flex items-start gap-3 py-3 transition-colors"
                      >
                        <span className="mc-slot mt-0.5 h-8 w-8 shrink-0 text-muted transition-colors group-hover:border-accent-line group-hover:text-accent">
                          <Icon className="h-3.5 w-3.5" strokeWidth={1.7} />
                        </span>
                        <div className="min-w-0">
                          <p className="text-[12.5px] font-medium text-ink/90 transition-colors group-hover:text-ink">
                            {skill.title}
                          </p>
                          <p className="mt-0.5 text-[10.5px] leading-relaxed text-muted">{skill.desc}</p>
                        </div>
                        <span className="ms-auto mt-1 font-mono text-[9px] text-muted/40">
                          {String(index + 1).padStart(2, "0")}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </Reveal>

            <Reveal y={18} delay={0.1}>
              <div className="panel p-5">
                <div className="flex flex-wrap gap-1.5">
                  {t.about.toolbelt.map((tool) => (
                    <span key={tool} className="tag">
                      <span className="h-1 w-1 bg-accent" />
                      {tool}
                    </span>
                  ))}
                </div>

                <div className="mt-4 overflow-hidden rounded-[2px] border border-line bg-[#080a0d]" dir="ltr">
                  <div className="flex items-center justify-between border-b border-line bg-white/[0.02] px-3 py-2">
                    <span className="flex items-center gap-1.5 font-mono text-[9.5px] text-muted">
                      <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                      zSpeeDx.java
                    </span>
                    <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-muted/50">
                      java 17
                    </span>
                  </div>
                  <pre className="overflow-x-auto p-3.5 font-mono text-[10.5px] leading-[1.75] text-[#c3c8d1]">
                    <code>
                      <span className="text-[#6b7482]">public class</span>{" "}
                      <span className="text-[color:var(--c-light)]">zSpeeDx</span>{" "}
                      <span className="text-[#6b7482]">implements</span>{" "}
                      <span className="text-[#c3c8d1]">FullstackDeveloper</span> {"{"}
                      {"\n"}
                      {"  "}<span className="text-[#6b7482]">private final int</span> years{" "}
                      <span className="text-[#6b7482]">=</span> <span className="text-accent">3</span>;{"\n"}
                      {"  "}<span className="text-[#6b7482]">private final int</span> servers{" "}
                      <span className="text-[#6b7482]">=</span> <span className="text-accent">50</span>;{"\n"}
                      {"  "}<span className="text-[#6b7482]">private final int</span> projects{" "}
                      <span className="text-[#6b7482]">=</span> <span className="text-accent">11</span>;{"\n"}
                      {"  "}<span className="text-[#6b7482]">private final String[]</span> stack{" "}
                      <span className="text-[#6b7482]">=</span> {"{"}
                      {"\n"}
                      {"    "}<span className="text-[#9fb58a]">"plugin_systems"</span>,{" "}
                      <span className="text-[#9fb58a]">"game_modes"</span>,{"\n"}
                      {"    "}<span className="text-[#9fb58a]">"ranks_permissions"</span>,{"\n"}
                      {"    "}<span className="text-[#9fb58a]">"npcs_holograms"</span>,{"\n"}
                      {"    "}<span className="text-[#9fb58a]">"performance"</span>,{" "}
                      <span className="text-[#9fb58a]">"community_setup"</span>
                      {"\n"}
                      {"  "}
                      {"}"};
                      {"\n"}
                      {"}"}
                    </code>
                  </pre>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
