import { useRef, useState } from "react";
import { Check, Copy, MessageSquare, Send, ShieldCheck, Sparkles } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { Button } from "@/components/ui/Button";
import { DiscordIcon } from "@/components/ui/DiscordIcon";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { copyText } from "@/hooks/useCountUp";
import { PROFILE } from "@/data/projects";
import { cn } from "@/utils/cn";

type CopyStatus = "idle" | "ok" | "error";

export function Contact() {
  const { t } = useApp();
  const [idStatus, setIdStatus] = useState<CopyStatus>("idle");
  const [messageStatus, setMessageStatus] = useState<CopyStatus>("idle");
  const [topic, setTopic] = useState(0);
  const [message, setMessage] = useState("");
  const idTimer = useRef<number | null>(null);
  const msgTimer = useRef<number | null>(null);

  const copyId = async () => {
    const ok = await copyText(PROFILE.discordId);
    setIdStatus(ok ? "ok" : "error");
    if (idTimer.current) window.clearTimeout(idTimer.current);
    idTimer.current = window.setTimeout(() => setIdStatus("idle"), 2600);
  };

  const copyMessage = async () => {
    const composed = `${t.contact.greeting} ${t.contact.greetingBody} ${t.contact.topics[topic]}.\n\n${
      message.trim() || "—"
    }`;
    const ok = await copyText(composed);
    setMessageStatus(ok ? "ok" : "error");
    if (msgTimer.current) window.clearTimeout(msgTimer.current);
    msgTimer.current = window.setTimeout(() => setMessageStatus("idle"), 2800);
  };

  return (
    <section id="contact" className="section section-anchor relative">
      <div className="container-x">
        <div className="grid items-start gap-8 lg:grid-cols-[1.02fr_0.98fr] lg:gap-6">
          <div>
            <SectionHeading
              kicker={t.contact.kicker}
              title={t.contact.title}
              description={t.contact.description}
            />

            <Reveal y={20} className="mt-8">
              <div className="discord-card p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="relative shrink-0">
                      <div className="mc-slot h-[62px] w-[62px] overflow-hidden">
                        <img
                          src={PROFILE.avatar}
                                              onError={(event) => {
                                                const img = event.currentTarget;
                                                if (img.dataset.avatarFallback) return;
                                                img.dataset.avatarFallback = "true";
                                                img.src =
                                                  "data:image/svg+xml;utf8," +
                                                  encodeURIComponent(
                                                    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e94b5c"/><stop offset="1" stop-color="#9c1024"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><path d="M160 150h192v58L230 306h122v58H160v-58l122-98H160z" fill="#fff"/></svg>',
                                                  );
                                              }}
                          alt={t.contact.imageAlt}
                          className="h-full w-full object-contain p-1"
                          loading="lazy"
                          width={62}
                          height={62}
                        />
                      </div>
                      <span className="absolute -bottom-1 -end-1 h-3 w-3 border-2 border-[#0b0d11] bg-emerald-400 shadow-[0_0_10px_#34d399]" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-[15px] font-semibold tracking-tight text-ink">Dev zSpeeDx</p>
                        <span className="inline-flex items-center gap-1 border border-accent-line bg-accent-soft px-1.5 py-0.5 font-mono text-[7.5px] uppercase tracking-[0.1em] text-[color:var(--c-light)]">
                          <DiscordIcon className="h-2.5 w-2.5" />
                          {t.contact.cardTag}
                        </span>
                      </div>
                      <p className="mt-1 text-[11px] text-muted">{t.contact.cardRole}</p>
                      <p className="mt-1 flex items-center gap-1.5 text-[10px] text-emerald-400/90">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                        {t.common.available}
                      </p>
                    </div>
                  </div>
                  <span className="mc-slot hidden h-9 w-9 shrink-0 text-accent sm:grid">
                    <Sparkles className="h-4 w-4" strokeWidth={1.7} />
                  </span>
                </div>

                <div className="mt-4 border border-line bg-black/25 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="meta-label">{t.contact.idLabel}</span>
                    <span className="flex items-center gap-1.5 font-mono text-[8px] uppercase tracking-[0.12em] text-emerald-400/80">
                      <ShieldCheck className="h-3 w-3" />
                      {t.common.officialContact}
                    </span>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                    <code className="discord-id" dir="ltr">
                      {PROFILE.discordId}
                    </code>
                    <button
                      type="button"
                      onClick={copyId}
                      className="inline-flex items-center gap-1.5 border border-line bg-white/[0.025] px-2 py-1.5 text-[9.5px] font-medium text-muted transition-colors hover:border-accent-line hover:text-accent"
                      aria-label={t.common.copyDiscord}
                    >
                      {idStatus === "ok" ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      {idStatus === "ok" ? t.common.copied : t.common.copy}
                    </button>
                  </div>
                </div>

                <p className="mt-3 text-[11.5px] leading-[1.8] text-muted">{t.contact.note}</p>

                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <Button
                    href={PROFILE.discordUrl}
                    external
                    icon={<DiscordIcon className="h-4 w-4" />}
                    className="flex-1"
                  >
                    {t.common.openDiscord}
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={copyId}
                    icon={idStatus === "ok" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    className="flex-1"
                  >
                    {idStatus === "ok" ? t.common.copied : t.common.copyDiscord}
                  </Button>
                </div>

                <div className="mt-3 flex items-center justify-between gap-2 border-t border-line pt-3">
                  <span className="font-mono text-[8.5px] uppercase tracking-[0.1em] text-muted/55" dir="ltr">
                    discord.com/users/···{PROFILE.discordId.slice(-4)}
                  </span>
                  <span className="flex gap-1" aria-hidden="true">
                    {[0.3, 0.55, 1].map((opacity) => (
                      <span key={opacity} className="h-1.5 w-1.5 bg-accent" style={{ opacity }} />
                    ))}
                  </span>
                </div>
              </div>
            </Reveal>

            <p className="sr-only" role="status" aria-live="polite">
              {idStatus === "ok"
                ? t.a11y.copiedStatus
                : idStatus === "error"
                  ? t.a11y.copyError
                  : ""}
            </p>

            <Reveal y={14} delay={0.08}>
              <div className="mt-3 flex items-center gap-2 px-1 text-[10.5px] text-muted/70">
                <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-accent/80" />
                {t.contact.privacy}
              </div>
            </Reveal>
          </div>

          {/* composer */}
          <Reveal y={22} delay={0.1}>
            <div className="panel overflow-hidden">
              <div className="flex items-center justify-between gap-3 border-b border-line p-4">
                <div className="flex items-center gap-2.5">
                  <span className="mc-slot h-8 w-8 text-accent">
                    <MessageSquare className="h-3.5 w-3.5" strokeWidth={1.8} />
                  </span>
                  <div>
                    <h3 className="text-[13px] font-semibold text-ink">{t.contact.composerTitle}</h3>
                    <p className="mt-0.5 text-[10px] text-muted">{t.contact.composerDesc}</p>
                  </div>
                </div>
                <span className="hidden font-mono text-[8px] uppercase tracking-[0.14em] text-muted/50 sm:block">
                  draft
                </span>
              </div>

              <div className="p-4">
                <span className="meta-label">{t.contact.topicLabel}</span>
                <div className="mt-2 flex flex-wrap gap-1.5" role="group" aria-label={t.contact.topicLabel}>
                  {t.contact.topics.map((item, index) => (
                    <button
                      key={item}
                      type="button"
                      className="topic-chip"
                      data-active={topic === index}
                      aria-pressed={topic === index}
                      onClick={() => setTopic(index)}
                    >
                      {item}
                    </button>
                  ))}
                </div>

                <label htmlFor="contact-message" className="meta-label mt-4 block">
                  {t.contact.messageLabel}
                </label>
                <textarea
                  id="contact-message"
                  value={message}
                  onChange={(event) => setMessage(event.target.value.slice(0, 500))}
                  placeholder={t.contact.placeholder}
                  rows={5}
                  maxLength={500}
                  className="field mt-2 resize-none"
                />
                <div className="mt-1 flex items-center justify-between gap-2">
                  <span className="text-[9.5px] text-muted/60">{t.contact.emptyNote}</span>
                  <span className="latin text-[9px] text-muted/55">{message.length}/500</span>
                </div>

                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <Button
                    variant="primary"
                    onClick={copyMessage}
                    icon={messageStatus === "ok" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    className="flex-1"
                  >
                    {messageStatus === "ok" ? t.contact.copiedMessage : t.contact.copyMessage}
                  </Button>
                  <Button
                    href={PROFILE.discordUrl}
                    external
                    variant="ghost"
                    icon={<Send className="h-4 w-4 rtl:-scale-x-100" />}
                    className="flex-1"
                  >
                    {t.contact.sendOnDiscord}
                  </Button>
                </div>

                <div
                  className={cn(
                    "mt-3 flex items-start gap-2 text-[10px] leading-relaxed",
                    messageStatus === "ok" ? "text-emerald-400/90" : "text-muted/70",
                  )}
                  role="status"
                  aria-live="polite"
                >
                  {messageStatus === "ok" ? (
                    <Check className="mt-0.5 h-3 w-3 shrink-0" />
                  ) : messageStatus === "error" ? (
                    <MessageSquare className="mt-0.5 h-3 w-3 shrink-0" />
                  ) : (
                    <span className="mt-1.5 h-1 w-1 shrink-0 bg-accent" aria-hidden="true" />
                  )}
                  {messageStatus === "ok"
                    ? t.contact.copyHint
                    : messageStatus === "error"
                      ? t.contact.copyFailed
                      : t.contact.greeting}
                </div>
              </div>

              <div className="flex items-center gap-3 border-t border-line bg-white/[0.015] px-4 py-3">
                <DiscordIcon className="h-4 w-4 shrink-0 text-[color:var(--c-light)]" />
                <p className="truncate font-mono text-[9px] uppercase tracking-[0.08em] text-muted" dir="ltr">
                  {PROFILE.discordUrl}
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
