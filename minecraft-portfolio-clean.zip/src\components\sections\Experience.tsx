import {
  Boxes,
  Coffee,
  Database,
  Gauge,
  Globe2,
  Layers,
  ScanFace,
  Server,
  ShieldCheck,
  Swords,
  Trophy,
  type LucideIcon,
} from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { PixelCube } from "@/components/ui/PixelCube";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PROFILE } from "@/data/projects";
import { TECH_GROUPS } from "@/data/tech";

const STEP_ICONS: LucideIcon[] = [Coffee, Server, ShieldCheck, ScanFace, Swords, Gauge];
const GROUP_ICONS: Record<string, LucideIcon> = { systems: Boxes, cores: Layers, network: Globe2, data: Database };

export function Experience() {
  const { t, lang } = useApp();

  return (
    <section id="experience" className="section section-anchor relative">
      <div className="container-x">
        <div className="grid items-start gap-10 lg:grid-cols-[1.18fr_0.82fr] lg:gap-8">
          <div>
            <SectionHeading
              kicker={t.experience.kicker}
              title={t.experience.title}
              description={t.experience.description}
            />

            <div className="relative mt-10">
              <div className="timeline-rail" aria-hidden="true" />
              <div className="flex flex-col gap-3">
                {t.experience.timeline.map((step, index) => {
                  const Icon = STEP_ICONS[index] ?? Coffee;
                  const isLast = index === t.experience.timeline.length - 1;
                  return (
                    <Reveal key={step.level} delay={index * 0.07} y={20}>
                      <div className="flex items-start gap-4">
                        <div className="relative flex flex-col items-center">
                          <div className="timeline-node" aria-hidden="true">
                            <Icon className="h-4 w-4" strokeWidth={1.8} />
                          </div>
                          {isLast ? (
                            <span className="mt-1 h-1.5 w-1.5 animate-pulse bg-accent shadow-[0_0_10px_var(--c)]" />
                          ) : null}
                        </div>

                        <div className="panel group flex-1 p-4 transition-colors duration-300 hover:border-accent-line sm:p-5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-accent">
                              {lang === "ar" ? "المستوى" : "Level"} {step.level}
                            </span>
                            <span className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-muted/50">
                              {isLast ? (lang === "ar" ? "مستمر" : "ongoing") : "unlocked"}
                            </span>
                          </div>
                          <h3 className="mt-1.5 text-[14.5px] font-semibold tracking-tight text-ink">
                            {step.title}
                          </h3>
                          <p className="mt-1.5 text-[11.5px] leading-[1.8] text-muted">{step.desc}</p>
                          <div className="mt-3 flex flex-wrap gap-1.5">
                            {step.tags.map((tag) => (
                              <span key={tag} className="tag !py-1 !text-[9px]">
                                <span className="h-1 w-1 bg-accent" />
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </Reveal>
                  );
                })}
              </div>
            </div>

            <Reveal y={16}>
              <div className="panel relative mt-4 ms-16 flex items-center gap-3 overflow-hidden p-3.5">
                <span className="mc-slot h-8 w-8 shrink-0 text-accent">
                  <Trophy className="h-3.5 w-3.5" strokeWidth={1.8} />
                </span>
                <p className="text-[11px] font-medium text-ink/85">{t.experience.summary}</p>
                <PixelCube size={26} className="ms-auto hidden opacity-40 sm:block" />
              </div>
            </Reveal>
          </div>

          {/* profile panel */}
          <Reveal y={22} delay={0.08} className="lg:sticky lg:top-[100px]">
            <div className="panel accent-frame overflow-hidden">
              <div className="flex items-center justify-between border-b border-line p-4">
                <div className="flex items-center gap-2.5">
                  <span className="mc-slot h-8 w-8 text-accent">
                    <Trophy className="h-3.5 w-3.5" strokeWidth={1.8} />
                  </span>
                  <h3 className="text-[13px] font-semibold text-ink">{t.experience.profileTitle}</h3>
                </div>
                <span className="flex gap-1" aria-hidden="true">
                  {[0.25, 0.5, 1].map((o) => (
                    <span key={o} className="h-1.5 w-1.5 bg-accent" style={{ opacity: o }} />
                  ))}
                </span>
              </div>

              <div className="p-4">
                {[
                  { label: t.experience.profileRows.experience, value: t.hero.xpValue, accent: false },
                  { label: t.experience.profileRows.servers, value: "50+", accent: true },
                  { label: t.experience.profileRows.projects, value: "11", accent: true },
                  { label: t.experience.profileRows.stack, value: "Java · Folia · Redis", accent: false },
                  { label: t.experience.profileRows.published, value: "BuiltByBit", accent: false },
                ].map((row) => (
                  <div className="info-row" key={row.label}>
                    <span className="meta-label self-center">{row.label}</span>
                    <span
                      dir={row.accent ? "ltr" : undefined}
                      className={
                        row.accent
                          ? "inline-flex justify-end font-mono text-[12px] text-[color:var(--c-light)] sm:text-end"
                          : "text-[12px] text-ink/85 sm:text-end"
                      }
                    >
                      {row.value}
                    </span>
                  </div>
                ))}

                <div className="mt-4">
                  <div className="flex items-center justify-between gap-2">
                    <span className="meta-label">{t.experience.progressLabel}</span>
                    <span className="font-mono text-[9px] text-accent">{t.common.level} 04</span>
                  </div>
                  <div className="mt-2 flex gap-1" aria-hidden="true">
                    {[0, 1, 2, 3].map((seg) => (
                      <span
                        key={seg}
                        className="h-2.5 flex-1 border border-accent-line bg-accent shadow-[inset_0_1px_0_rgba(255,255,255,.3)]"
                        style={{ opacity: 1 - seg * 0.14 }}
                      />
                    ))}
                  </div>
                  <p className="mt-2 font-mono text-[9.5px] uppercase tracking-[0.08em] text-muted">
                    {t.experience.progressValue}
                  </p>
                </div>
              </div>

              <div className="border-t border-line p-4">
                <h4 className="meta-label">{t.experience.focusTitle}</h4>
                <ul className="mt-2.5 grid gap-2">
                  {t.experience.focus.map((item) => (
                    <li key={item} className="flex items-center gap-2 text-[11.5px] text-muted">
                      <span className="grid h-4 w-4 shrink-0 place-items-center border border-accent-line bg-accent-soft" aria-hidden="true">
                        <span className="h-1 w-1 bg-accent" />
                      </span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <a
                href={PROFILE.builtByBit}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between border-t border-line bg-white/[0.015] px-4 py-3 transition-colors hover:bg-accent-soft"
              >
                <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-muted">
                  builtbybit.com
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] text-accent">
                  {lang === "ar" ? "زيارة الموقع" : "Visit site"}
                  <span aria-hidden="true" className="rtl:-scale-x-100">↗</span>
                </span>
              </a>
            </div>
          </Reveal>
        </div>

        {/* platform stack */}
        <div className="mt-14">
          <div className="flex flex-col justify-between gap-4 border-t border-line pt-8 lg:flex-row lg:items-end">
            <div className="max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 bg-accent" aria-hidden="true" />
                <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-accent">
                  {t.experience.kicker.split("/")[0].trim()} / Stack
                </span>
              </div>
              <h3 className="mt-2.5 text-[clamp(1.35rem,2.6vw,1.85rem)] font-semibold tracking-tight text-ink">
                {t.experience.stackTitle}
              </h3>
              <p className="mt-2 max-w-xl text-[12px] leading-[1.8] text-muted">{t.experience.stackDesc}</p>
            </div>
            <span className="shrink-0 font-mono text-[9px] uppercase tracking-[0.14em] text-muted/60">
              {t.experience.stackNote}
            </span>
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {TECH_GROUPS.map((group, groupIndex) => {
              const GroupIcon = GROUP_ICONS[group.id] ?? Layers;
              return (
                <Reveal key={group.id} delay={groupIndex * 0.06} y={18}>
                  <div className="panel h-full overflow-hidden">
                    <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <span className="mc-slot h-8 w-8 text-accent">
                          <GroupIcon className="h-3.5 w-3.5" strokeWidth={1.8} />
                        </span>
                        <h4 className="text-[12px] font-semibold tracking-tight text-ink">
                          {group.label[lang]}
                        </h4>
                      </div>
                      <span className="font-mono text-[9px] text-muted/50">
                        {String(group.items.length).padStart(2, "0")}
                      </span>
                    </div>
                    <ul className="p-2">
                      {group.items.map((item) => (
                        <li
                          key={item.name}
                          className="flex items-center justify-between gap-3 border-b border-line/60 px-2 py-2.5 last:border-b-0"
                        >
                          <div className="min-w-0">
                            <p className="font-mono text-[11px] font-medium text-ink/90">{item.name}</p>
                            <p className="mt-0.5 truncate text-[9.5px] text-muted/75">{item.desc[lang]}</p>
                          </div>
                          <span className="h-1 w-1 shrink-0 bg-accent" aria-hidden="true" />
                        </li>
                      ))}
                    </ul>
                  </div>
                </Reveal>
              );
            })}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="tag !py-1 !text-[9px]">
              <span className="h-1 w-1 bg-accent" />
              {t.experience.stackMore}
            </span>
            {["APIs", "GUI Systems", "Ranks & Permissions", "NPCs & Holograms", "Survival · BoxPvP · SMP · Duels", "Performance"].map((extra) => (
              <span key={extra} className="tag !py-1 !text-[9px]">
                {extra}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
