import {
  ArrowDown,
  ArrowRight,
  Coffee,
  Gauge,
  ScanFace,
  ShieldCheck,
  Sparkles,
  Swords,
} from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { Button } from "@/components/ui/Button";
import { DiscordIcon } from "@/components/ui/DiscordIcon";
import { Reveal } from "@/components/ui/Reveal";
import { PROFILE } from "@/data/projects";
import { useTilt } from "@/hooks/useTilt";
import { TECH_NAMES } from "@/data/tech";

const HOTBAR = [
  { Icon: Coffee, label: "Java", active: true },
  { Icon: ShieldCheck, label: "Ranks & Permissions", active: false },
  { Icon: ScanFace, label: "NPCs & Holograms", active: false },
  { Icon: Swords, label: "Survival · BoxPvP · SMP · Duels", active: false },
  { Icon: Gauge, label: "Performance & Full Setup", active: false },
];

const HERO_STACK = TECH_NAMES.filter((name) => ["Paper", "Purpur", "Folia", "Canvas", "Leaf", "Velocity", "MySQL", "Redis"].includes(name));

export function Hero() {
  const { t } = useApp();
  const cardTilt = useTilt<HTMLDivElement>({ max: 5 });

  return (
    <section id="home" className="relative overflow-hidden pt-[112px] pb-14 sm:pb-20 lg:pt-[124px] lg:pb-20">
      <div className="container-x relative">
        <div className="grid items-center gap-12 lg:grid-cols-[1.04fr_0.96fr] lg:gap-8 xl:gap-12">
          {/* copy */}
          <div className="relative z-10 min-w-0">
            <Reveal y={12}>
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                <span className="status-chip">
                  <span className="status-dot" />
                  {t.common.available}
                </span>
                <span className="eyebrow">
                  <span className="eyebrow-dot" />
                  {t.hero.kicker}
                </span>
              </div>
            </Reveal>

            <Reveal y={28} delay={0.06}>
              <h1 className="hero-title mt-5 text-ink">
                <span className="block">{t.hero.firstName}</span>
                <span className="mt-1 flex items-baseline gap-3">
                  <span className="text-gradient">{t.hero.lastName}</span>
                  <span
                    className="mb-2 hidden h-2.5 w-2.5 shrink-0 bg-accent shadow-[0_0_18px_var(--c-glow)] sm:block"
                    aria-hidden="true"
                  />
                </span>
              </h1>
            </Reveal>

            <Reveal delay={0.12}>
              <div className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2">
                <span className="hero-role">{t.hero.role}</span>
                <span className="hidden h-px w-8 bg-line sm:block" aria-hidden="true" />
                <span className="hidden font-mono text-[8px] uppercase tracking-[0.1em] text-muted/70 sm:inline">
                  {t.hero.kicker}
                </span>
              </div>
            </Reveal>

            <Reveal delay={0.16}>
              <p className="mt-4 text-[clamp(1.15rem,2.1vw,1.5rem)] font-medium leading-snug tracking-tight text-ink/90">
                {t.hero.statement}
              </p>
            </Reveal>

            <Reveal delay={0.2}>
              <p className="lede mt-3.5 max-w-[560px]">{t.hero.description}</p>
            </Reveal>

            <Reveal delay={0.26}>
              <div className="mt-7 flex flex-wrap items-center gap-2.5">
                <Button href="#projects" iconRight={<ArrowRight className="h-4 w-4 rtl:-scale-x-100" />}>
                  {t.hero.explore}
                </Button>
                <Button href="#contact" variant="ghost">
                  {t.hero.contact}
                </Button>
                <Button
                  href={PROFILE.discordUrl}
                  external
                  variant="quiet"
                  icon={<DiscordIcon className="h-4 w-4" />}
                  ariaLabel={`${t.hero.profile} (${t.common.external})`}
                >
                  {t.hero.profile}
                </Button>
              </div>
            </Reveal>

            <Reveal delay={0.32}>
              <div className="mt-8 flex max-w-md items-start gap-5 sm:mt-9 sm:gap-7">
                {t.hero.stats.map((stat) => (
                  <div key={stat.label} className="stat-chip flex-1">
                    <span className="stat-value inline-flex" dir="ltr">
                      <span className="latin">{stat.value}</span>
                      <span className="suffix">{stat.suffix}</span>
                    </span>
                    <span className="text-[10.5px] leading-tight text-muted">{stat.label}</span>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.36}>
              <div className="mt-7 border-t border-line pt-4">
                <p className="meta-label" dir="auto">{t.hero.stackLabel}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {HERO_STACK.map((name) => (
                    <span key={name} className="tag !py-1 !text-[9px]">
                      <span className="h-1 w-1 bg-accent" />
                      {name}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.4}>
              <div className="mt-6 flex items-center gap-3">
                <a
                  href="#about"
                  className="group inline-flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.22em] text-muted transition-colors hover:text-accent"
                >
                  <span className="grid h-7 w-7 place-items-center border border-line transition-colors group-hover:border-accent-line">
                    <ArrowDown className="h-3.5 w-3.5" />
                  </span>
                  {t.common.scroll}
                </a>
                <span className="hairline hidden max-w-[120px] flex-1 sm:block" />
              </div>
            </Reveal>
          </div>

          {/* developer card */}
          <Reveal y={30} delay={0.1} className="relative z-10 mx-auto w-full min-w-0 max-w-[418px]">
            <div className="relative">
              <div className="portrait-glow" aria-hidden="true" />

              <div ref={cardTilt} className="player-card tilt-card has-spotlight pixel-corners relative p-2">
                <span className="corner corner-tl" />
                <span className="corner corner-tr" />
                <span className="corner corner-bl" />
                <span className="corner corner-br" />

                <div className="flex items-center justify-between px-2 py-2">
                  <span className="meta-label flex items-center gap-1.5">
                    <Sparkles className="h-3 w-3 text-accent" />
                    {t.hero.cardTag}
                  </span>
                  <span className="flex items-center gap-1" aria-hidden="true">
                    {[0.3, 0.55, 1].map((opacity) => (
                      <span key={opacity} className="h-1.5 w-1.5 bg-accent" style={{ opacity }} />
                    ))}
                  </span>
                </div>

                <div className="hero-logo-stage pixel-cut relative aspect-square overflow-hidden border border-line">
                  <div className="absolute inset-0 bg-gradient-to-t from-[#080a0d] via-transparent to-[#080a0d]/35" />
                  <div className="absolute inset-x-0 top-3 z-10 flex items-start justify-between px-3">
                    <div className="flex items-center gap-2 border border-white/15 bg-black/55 px-2 py-1">
                      <span className="h-1.5 w-1.5 animate-pulse bg-emerald-400 shadow-[0_0_8px_#34d399]" />
                      <span className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-white/85">
                        {t.hero.status}
                      </span>
                    </div>
                    <div className="mc-slot h-14 w-14 flex-col gap-0 border-white/20 bg-black/55">
                      <span className="font-mono text-[7px] uppercase tracking-[0.18em] text-white/55">
                        {t.common.level}
                      </span>
                      <span className="latin text-lg font-bold leading-none text-accent">03</span>
                    </div>
                  </div>

                  <div className="absolute inset-0 flex items-center justify-center px-10 pb-16 pt-10">
                    <img
                      src={PROFILE.avatar}
                                          onError={(event) => {
                                            const img = event.currentTarget;
                                            if (img.dataset.avatarFallback) return;
                                            img.dataset.avatarFallback = "true";
                                            img.src =
                                              "data:image/svg+xml;utf8," +
                                              encodeURIComponent(
                                                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e94b5c"/><stop offset="1" stop-color="#9c1024"/></linearGradient></defs><rect width="512" height="512" rx="112" fill="url(#g)"/><path d="M160 150h192v58L230 306h122v58H160v-58l122-98H160z" fill="#fff"/></svg>',
                                              );
                                          }}
                      alt={t.hero.imageAlt}
                      className="hero-logo w-full max-w-[248px] object-contain"
                      width={512}
                      height={512}
                      loading="eager"
                      decoding="async"
                    />
                  </div>

                  <div className="absolute inset-x-3 bottom-3">
                    <div className="mb-2 flex items-end justify-between gap-2">
                      <div>
                        <p className="text-[17px] font-bold leading-tight tracking-tight text-white">
                          Dev zSpeeDx
                        </p>
                        <p className="mt-0.5 font-mono text-[8.5px] uppercase tracking-[0.14em] text-[color:var(--c-light)]">
                          {t.hero.cardRole}
                        </p>
                      </div>
                      <span className="hidden items-center gap-1 border border-white/15 bg-black/40 px-1.5 py-1 font-mono text-[7.5px] uppercase tracking-[0.1em] text-white/60 sm:inline-flex">
                        PAPER
                      </span>
                    </div>
                    <div className="xp-track">
                      <div className="xp-fill" style={{ width: "82%" }} />
                    </div>
                    <div className="mt-1.5 flex items-center justify-between font-mono text-[8px] uppercase tracking-[0.12em] text-white/45">
                      <span>{t.hero.xp}</span>
                      <span className="text-[color:var(--c-light)]">{t.hero.xpValue}</span>
                    </div>
                  </div>
                </div>

                <div className="px-2 pb-1.5 pt-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="meta-label">{t.hero.focus}</p>
                      <p className="mt-1 truncate text-[11px] font-medium text-ink/90">{t.hero.focusValue}</p>
                    </div>
                    <div className="flex shrink-0 gap-1" aria-label="Minecraft hotbar">
                      {HOTBAR.map(({ Icon, label, active }) => (
                        <span
                          key={label}
                          className={`mc-slot h-8 w-8 ${
                            active ? "border-accent-line bg-accent-soft text-accent" : "text-muted"
                          }`}
                          title={label}
                        >
                          <Icon className="h-3.5 w-3.5" strokeWidth={1.8} />
                        </span>
                      ))}
                    </div>
                  </div>
                  <div
                    className="mt-3 flex items-center justify-between border-t border-line pt-2 font-mono text-[8px] uppercase tracking-[0.12em] text-muted/70"
                    dir="ltr"
                  >
                    <span className="truncate">{t.hero.coord}</span>
                    <span className="ms-2 hidden shrink-0 sm:inline">v1.1.0</span>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-24 opacity-60"
        style={{
          backgroundImage: "linear-gradient(to top, color-mix(in srgb, var(--c) 7%, transparent), transparent)",
        }}
        aria-hidden="true"
      />
    </section>
  );
}
