import { useState } from "react";
import { ArrowUpRight, ExternalLink, Layers, ZoomIn } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { Button } from "@/components/ui/Button";
import { ImageLightbox } from "@/components/ui/ImageLightbox";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PROJECTS, type Project } from "@/data/projects";
import { useTilt } from "@/hooks/useTilt";

function ProjectCard({ project }: { project: Project }) {
  const { t, lang } = useApp();
  const [preview, setPreview] = useState(false);
  const tilt = useTilt<HTMLElement>({ max: 3.5 });

  return (
    <article ref={tilt} className="project-card tilt-card has-spotlight group flex h-full flex-col">
      <div className="project-art relative">
        <div className="absolute inset-x-0 top-0 z-10 flex items-center justify-between gap-2 p-3">
          <span className="inline-flex items-center gap-1.5 border border-accent-line bg-[#080a0d]/80 px-1.5 py-1 font-mono text-[8px] uppercase tracking-[0.12em] text-[color:var(--c-light)]">
            <span className="h-1 w-1 bg-accent shadow-[0_0_6px_var(--c)]" />
            {t.projects.publishedBadge}
          </span>
          <span className="border border-line bg-[#080a0d]/80 px-1.5 py-1 font-mono text-[8px] uppercase tracking-[0.14em] text-muted">
            #{project.slot}
          </span>
        </div>

        <img
          src={project.image}
          alt={`${project.name} — ${t.common.viewImage}`}
          className="aspect-[16/10] w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.035]"
          loading="lazy"
          decoding="async"
          width={1200}
          height={750}
        />

        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0a0c10] via-transparent to-[#0a0c10]/25" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-accent/50" />

        <div className="pointer-events-none absolute bottom-3 start-3 z-10 flex items-end gap-2">
          <span className="mc-slot h-9 w-9 bg-[#080a0d]/80 text-accent">
            <Layers className="h-4 w-4" strokeWidth={1.7} />
          </span>
          <div className="pb-0.5">
            <h3 className="text-[17px] font-bold leading-tight tracking-tight text-white">
              {project.name}
            </h3>
            <p className="mt-0.5 font-mono text-[8px] uppercase tracking-[0.14em] text-[color:var(--c-light)]">
              {lang === "ar" ? "إضافة ماينكرافت" : "Minecraft Plugin"}
            </p>
          </div>
        </div>

        <button
          type="button"
          className="zoom-hit"
          onClick={() => setPreview(true)}
          aria-label={`${project.name} — ${t.common.viewImage}`}
        >
          <span className="zoom-pill">
            <ZoomIn className="h-3.5 w-3.5" />
            {t.common.preview}
          </span>
        </button>
      </div>

      <div className="flex flex-1 flex-col p-4 sm:p-[18px]">
        <p className="text-[11.5px] leading-[1.8] text-muted">{project.description[lang]}</p>

        <div className="mt-auto flex items-center justify-between gap-3 pt-4">
          <span className="inline-flex items-center gap-1.5 font-mono text-[8.5px] uppercase tracking-[0.1em] text-muted/55">
            <span className="h-1 w-1 bg-accent" />
            builtbybit.com
          </span>
          <Button
            href={project.link}
            external
            size="sm"
            variant="primary"
            className="btn-cta shrink-0"
            ariaLabel={`${project.name} — ${t.projects.viewOn} (${t.common.external})`}
            iconRight={<ExternalLink className="h-3 w-3" />}
          >
            {t.common.viewProject}
          </Button>
        </div>
      </div>

      <ImageLightbox
        open={preview}
        src={project.image}
        title={project.name}
        subtitle={t.common.resourcePage}
        closeLabel={t.common.close}
        onClose={() => setPreview(false)}
      />
    </article>
  );
}

export function Projects() {
  const { t } = useApp();

  return (
    <section id="projects" className="section section-anchor relative">
      <div className="container-x">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHeading
            kicker={t.projects.kicker}
            title={t.projects.title}
            description={t.projects.description}
          />
          <Reveal delay={0.1} className="shrink-0">
            <div className="flex gap-6 sm:gap-8">
              {t.projects.stats.map((stat) => (
                <div key={stat.label} className="min-w-[64px]">
                  <div className="stat-value text-[1.55rem]">
                    <span className="latin">{stat.value}</span>
                  </div>
                  <p className="mt-1 text-[10.5px] leading-tight text-muted">{stat.label}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:gap-5">
          {PROJECTS.map((project, index) => (
            <Reveal key={project.id} delay={index * 0.06} y={20}>
              <ProjectCard project={project} />
            </Reveal>
          ))}
        </div>

        <Reveal y={14}>
          <div className="panel mt-5 flex flex-col items-start justify-between gap-3 p-4 sm:flex-row sm:items-center">
            <div className="flex items-center gap-2.5">
              <span className="h-1.5 w-1.5 shrink-0 bg-accent" aria-hidden="true" />
              <p className="text-[11px] leading-relaxed text-muted">{t.projects.note}</p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <span className="font-mono text-[10px] text-muted">
                <span className="text-accent">04</span>/11
              </span>
              <div className="flex gap-1" aria-hidden="true">
                {PROJECTS.map((project) => (
                  <span
                    key={project.id}
                    className="h-3.5 w-3.5 border border-accent-line bg-accent shadow-[inset_0_1px_0_rgba(255,255,255,.35)]"
                  />
                ))}
                {Array.from({ length: 7 }).map((_, index) => (
                  <span key={index} className="h-3.5 w-3.5 border border-line bg-white/[0.03]" />
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal y={12}>
          <a
            href="https://builtbybit.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-1.5 text-[10.5px] text-muted transition-colors hover:text-accent"
          >
            {t.common.builtByBit}
            <ArrowUpRight className="h-3 w-3 rtl:-scale-x-100" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
