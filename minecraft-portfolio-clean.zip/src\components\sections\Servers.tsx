import { useState, type CSSProperties } from "react";
import { Server as ServerIcon, ZoomIn } from "lucide-react";
import { useApp } from "@/app/AppProvider";
import { ImageLightbox } from "@/components/ui/ImageLightbox";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { SERVERS, type Server } from "@/data/servers";
import { useTilt } from "@/hooks/useTilt";
import { cn } from "@/utils/cn";

const TONES: Record<string, string> = {
  red: "#ff0040",
  cyan: "#22d3ee",
  ice: "#7cc9f2",
  violet: "#b46bff",
  ember: "#ff5a3c",
  blue: "#3b82f6",
};

function ServerCard({ server, index }: { server: Server; index: number }) {
  const { t } = useApp();
  const [preview, setPreview] = useState(false);
  const tilt = useTilt<HTMLElement>({ max: 3.5 });

  return (
    <article
      ref={tilt}
      className="server-card tilt-card has-spotlight group relative overflow-hidden border border-line bg-panel"
      style={{ "--server-tone": TONES[server.tone] ?? "var(--c)" } as CSSProperties}
    >
      <div className="server-plate relative aspect-[5/4] overflow-hidden">
        <div className="pointer-events-none absolute inset-0 z-0 grid place-items-center" aria-hidden="true">
          <span
            className="server-halo"
            style={{
              background:
                "radial-gradient(closest-side, color-mix(in srgb, var(--server-tone) 24%, transparent), transparent 72%)",
            }}
          />
        </div>

        <img
          src={server.image}
          alt={`${server.name} logo`}
          className="server-logo relative z-[1] h-full w-full object-contain p-[8%] transition-transform duration-500 ease-out group-hover:scale-[1.035]"
          loading="lazy"
          decoding="async"
          width={640}
          height={512}
        />

        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-center justify-between p-3">
          <span className="border border-white/15 bg-black/50 px-1.5 py-1 font-mono text-[8px] uppercase tracking-[0.14em] text-white/80 backdrop-blur-[2px]">
            #{String(index + 1).padStart(2, "0")}
          </span>
          <span
            className="server-chip inline-flex items-center gap-1.5 bg-black/50 px-1.5 py-1 font-mono text-[8px] uppercase tracking-[0.1em] backdrop-blur-[2px]"
            style={{
              color: "color-mix(in srgb, var(--server-tone) 76%, #ffffff)",
              borderColor: "color-mix(in srgb, var(--server-tone) 45%, transparent)",
            }}
          >
            <span
              className="h-1 w-1"
              style={{ background: "var(--server-tone)", boxShadow: "0 0 6px var(--server-tone)" }}
            />
            {t.servers.workedOn}
          </span>
        </div>

        <button
          type="button"
          className="zoom-hit"
          onClick={() => setPreview(true)}
          aria-label={`${server.name} — ${t.common.viewImage}`}
        >
          <span className="zoom-pill">
            <ZoomIn className="h-3.5 w-3.5" />
            {t.common.preview}
          </span>
        </button>
      </div>

      <div className="relative border-t border-line px-3.5 py-3">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[var(--server-tone)]/60 to-transparent" />
        <div className="flex items-center gap-2.5">
          <span className="mc-slot h-9 w-9 shrink-0" style={{ color: "var(--server-tone)" }}>
            <ServerIcon className="h-4 w-4" strokeWidth={1.8} />
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-[15px] font-bold leading-tight tracking-tight text-white">
              {server.name}
            </h3>
            <p className="mt-0.5 font-mono text-[8px] uppercase tracking-[0.14em] text-white/50">
              {t.servers.network}
            </p>
          </div>
          <span className="flex shrink-0 gap-[3px]" aria-hidden="true">
            {Array.from({ length: 5 }).map((_, bar) => (
              <span
                key={bar}
                className={cn("h-2.5 w-[3px] border border-white/10")}
                style={{
                  background: bar < 4 ? "var(--server-tone)" : "rgba(255,255,255,.08)",
                  opacity: 0.9 - bar * 0.12,
                }}
              />
            ))}
          </span>
        </div>
      </div>

      <ImageLightbox
        open={preview}
        src={server.image}
        title={server.name}
        subtitle={t.servers.network}
        closeLabel={t.common.close}
        onClose={() => setPreview(false)}
      />
    </article>
  );
}

export function Servers() {
  const { t } = useApp();

  return (
    <section id="servers" className="section section-anchor relative">
      <div className="container-x">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHeading
            kicker={t.servers.kicker}
            title={t.servers.title}
            description={t.servers.description}
          />
          <Reveal delay={0.1} className="shrink-0">
            <div className="flex gap-6">
              <div>
                <div className="stat-value text-[1.55rem]">
                  <span className="latin">06</span>
                </div>
                <p className="mt-1 max-w-[92px] text-[10.5px] leading-tight text-muted">
                  {t.servers.count}
                </p>
              </div>
              <div>
                <div className="stat-value text-[1.55rem]">
                  <span className="latin">50</span>
                  <span className="suffix">+</span>
                </div>
                <p className="mt-1 max-w-[92px] text-[10.5px] leading-tight text-muted">
                  {t.common.serversWorkedOn}
                </p>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVERS.map((server, index) => (
            <Reveal key={server.id} delay={index * 0.05} y={18}>
              <ServerCard server={server} index={index} />
            </Reveal>
          ))}
        </div>

        <Reveal y={12}>
          <p className="mt-4 flex items-start gap-2 text-[10.5px] leading-relaxed text-muted/70">
            <span className="mt-1.5 h-1 w-1 shrink-0 bg-accent" aria-hidden="true" />
            {t.servers.note}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
