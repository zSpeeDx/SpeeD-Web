import { useCountUp } from "@/hooks/useCountUp";

export function AnimatedNumber({
  value,
  suffix = "",
  active,
  className = "",
  duration = 1500,
}: {
  value: number;
  suffix?: string;
  active: boolean;
  className?: string;
  duration?: number;
}) {
  const current = useCountUp(value, active, duration);
  return (
    <span className={`inline-flex ${className}`} aria-label={`${value}${suffix}`} dir="ltr">
      <span className="latin">{current}</span>
      {suffix ? <span className="suffix">{suffix}</span> : null}
    </span>
  );
}
