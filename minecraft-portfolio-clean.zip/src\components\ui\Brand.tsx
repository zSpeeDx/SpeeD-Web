import { useApp } from "@/app/AppProvider";
import { PixelLogo } from "@/components/ui/PixelCube";
import { cn } from "@/utils/cn";

export function Brand({ className, onClick }: { className?: string; onClick?: () => void }) {
  const { lang } = useApp();
  return (
    <a
      href="#home"
      onClick={onClick}
      className={cn("group inline-flex items-center gap-2.5", className)}
      aria-label="Dev zSpeeDx — home"
    >
      <span className="relative grid place-items-center">
        <span className="absolute inset-0 -m-1 bg-accent/20 opacity-0 blur-md transition-opacity duration-300 group-hover:opacity-100" />
        <PixelLogo className="transition-transform duration-300 group-hover:-rotate-6" />
      </span>
      <span className="flex flex-col">
        <span className="text-[15px] font-bold leading-none tracking-tight text-ink">
          Dev <span className="accent-text">zSpeeDx</span>
        </span>
        <span className="mt-1 font-mono text-[7.5px] uppercase leading-none tracking-[0.2em] text-muted">
          {lang === "ar" ? "مطوّر ماينكرافت فل ستاك" : "Minecraft Fullstack Dev"}
        </span>
      </span>
    </a>
  );
}
