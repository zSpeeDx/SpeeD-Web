import type { MouseEvent, ReactNode } from "react";
import { cn } from "@/utils/cn";

type ButtonProps = {
  children: ReactNode;
  href?: string;
  external?: boolean;
  variant?: "primary" | "ghost" | "quiet";
  size?: "md" | "sm";
  icon?: ReactNode;
  iconRight?: ReactNode;
  className?: string;
  onClick?: (event: MouseEvent<HTMLElement>) => void;
  type?: "button" | "submit";
  disabled?: boolean;
  ariaLabel?: string;
  title?: string;
};

function spawnRipple(event: MouseEvent<HTMLElement>) {
  const host = event.currentTarget;
  const rect = host.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 2;
  const ripple = document.createElement("span");
  ripple.className = "ripple-ink";
  ripple.style.width = `${size}px`;
  ripple.style.height = `${size}px`;
  ripple.style.left = `${event.clientX - rect.left}px`;
  ripple.style.top = `${event.clientY - rect.top}px`;
  host.appendChild(ripple);
  window.setTimeout(() => ripple.remove(), 680);
}

export function Button({
  children,
  href,
  external = false,
  variant = "primary",
  size = "md",
  icon,
  iconRight,
  className,
  onClick,
  type = "button",
  disabled = false,
  ariaLabel,
  title,
}: ButtonProps) {
  const classes = cn("btn", `btn-${variant}`, size === "sm" && "btn-sm", className);
  const content = (
    <span className="relative z-10 inline-flex items-center gap-[inherit]">
      {icon}
      {children}
      {iconRight}
    </span>
  );

  const handleClick = (event: MouseEvent<HTMLElement>) => {
    spawnRipple(event);
    onClick?.(event);
  };

  if (href) {
    return (
      <a
        href={href}
        className={classes}
        onClick={handleClick}
        aria-label={ariaLabel}
        title={title}
        {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      type={type}
      className={classes}
      onClick={handleClick}
      disabled={disabled}
      aria-label={ariaLabel}
      title={title}
    >
      {content}
    </button>
  );
}

export function IconLink({
  href,
  label,
  children,
  external = true,
}: {
  href: string;
  label: string;
  children: ReactNode;
  external?: boolean;
}) {
  return (
    <a
      href={href}
      className="btn-icon"
      aria-label={label}
      title={label}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
    >
      {children}
    </a>
  );
}
