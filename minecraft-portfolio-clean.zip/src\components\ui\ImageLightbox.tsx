import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "motion/react";
import { X, ZoomIn } from "lucide-react";

type Props = {
  open: boolean;
  src: string;
  title: string;
  subtitle?: string;
  closeLabel: string;
  onClose: () => void;
};

export function ImageLightbox({ open, src, title, subtitle, closeLabel, onClose }: Props) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const timer = window.setTimeout(() => closeRef.current?.focus(), 60);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", onKey);
      window.clearTimeout(timer);
    };
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open ? (
        <motion.div
          className="lightbox"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
        >
          <div className="lightbox-backdrop" onClick={onClose} aria-hidden="true" />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className="lightbox-panel"
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="lightbox-head">
              <div className="min-w-0">
                <p className="truncate text-[13px] font-semibold text-ink">{title}</p>
                {subtitle ? (
                  <p className="meta-label mt-1 flex items-center gap-1.5">
                    <ZoomIn className="h-3 w-3 text-accent" />
                    {subtitle}
                  </p>
                ) : null}
              </div>
              <button
                ref={closeRef}
                type="button"
                className="btn-icon shrink-0"
                onClick={onClose}
                aria-label={closeLabel}
                title={closeLabel}
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="lightbox-body">
              <img
                key={src}
                src={src}
                alt={title}
                className="mx-auto max-h-[72vh] w-full object-contain"
                onError={(event) => {
                  event.currentTarget.style.display = "none";
                }}
              />
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>,
    document.body,
  );
}
