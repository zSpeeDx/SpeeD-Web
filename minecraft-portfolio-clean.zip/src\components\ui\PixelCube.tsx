import type { CSSProperties } from "react";
import { cn } from "@/utils/cn";

export function PixelCube({
  size = 48,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <div
      className={cn("voxel", className)}
      style={{ "--voxel-size": `${size}px` } as CSSProperties}
      aria-hidden="true"
    >
      <div className="voxel-face voxel-top" />
      <div className="voxel-face voxel-left" />
      <div className="voxel-face voxel-right" />
    </div>
  );
}

export function PixelLogo({ className }: { className?: string }) {
  return (
    <span className={cn("pixel-logo", className)} aria-hidden="true">
      {Array.from({ length: 9 }).map((_, i) => (
        <span key={i} />
      ))}
    </span>
  );
}
