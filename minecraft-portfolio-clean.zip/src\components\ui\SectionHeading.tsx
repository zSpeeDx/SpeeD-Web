import { Reveal } from "@/components/ui/Reveal";

export function SectionHeading({
  kicker,
  title,
  description,
  align = "start",
}: {
  kicker: string;
  title: string;
  description?: string;
  align?: "start" | "center";
}) {
  const centered = align === "center";
  return (
    <div className={centered ? "mx-auto max-w-2xl text-center" : "max-w-3xl"}>
      <Reveal y={14}>
        <div className={`flex items-center gap-3 ${centered ? "justify-center" : ""}`}>
          <span className="flex gap-1" aria-hidden="true">
            <span className="h-1.5 w-1.5 bg-accent" />
            <span className="h-1.5 w-1.5 bg-accent/60" />
            <span className="h-1.5 w-1.5 bg-accent/30" />
          </span>
          <span className="font-mono text-[10px] font-medium uppercase tracking-[0.24em] text-accent">
            {kicker}
          </span>
          <span className="h-px w-10 bg-line" aria-hidden="true" />
        </div>
      </Reveal>
      <Reveal delay={0.07}>
        <h2 className="heading-lg mt-5 text-ink">{title}</h2>
      </Reveal>
      {description ? (
        <Reveal delay={0.13}>
          <p className={`lede mt-4 ${centered ? "mx-auto" : "max-w-2xl"}`}>{description}</p>
        </Reveal>
      ) : null}
    </div>
  );
}
