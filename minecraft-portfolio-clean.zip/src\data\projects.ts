import zxborrow from "@/assets/projects/zxborrow.svg";
import zxhomes from "@/assets/projects/zxhomes.svg";
import zxauction from "@/assets/projects/zxauction.svg";
import zxteams from "@/assets/projects/zxteams.svg";
import profileZ from "@/assets/profile-z.svg";

export type Project = {
  id: string;
  name: string;
  slot: string;
  link: string;
  image: string;
  description: { en: string; ar: string };
};

export const PROJECTS: Project[] = [
  {
    id: "zxborrow",
    name: "ZxBorrow",
    slot: "01",
    link: "https://builtbybit.com/resources/zxborrow.132919/",
    image: zxborrow,
    description: {
      en: "A published Minecraft plugin from my project collection. The full overview, requirements and documentation are on the official BuiltByBit resource page.",
      ar: "إضافة ماينكرافت منشورة من مجموعة مشاريعي. تجد الوصف الكامل والمتطلبات والتوثيق في صفحة المورد الرسمية على BuiltByBit.",
    },
  },
  {
    id: "zxhomes",
    name: "ZxHomes",
    slot: "02",
    link: "https://builtbybit.com/resources/zxhomes.132910/",
    image: zxhomes,
    description: {
      en: "A published Minecraft plugin, available on BuiltByBit. Everything about the resource — features, compatibility and support — lives on its official page.",
      ar: "إضافة ماينكرافت منشورة ومتاحة على BuiltByBit. كل تفاصيل المورد — الميزات والتوافق والدعم — موجودة في صفحته الرسمية.",
    },
  },
  {
    id: "zxauction",
    name: "ZxAuction",
    slot: "03",
    link: "https://builtbybit.com/resources/zxauction.132899/",
    image: zxauction,
    description: {
      en: "One of my publicly released Minecraft plugins. Visit the BuiltByBit listing for the complete resource information and documentation.",
      ar: "واحدة من إضافات ماينكرافت التي نشرتها للعامة. تفضل بزيارة صفحة BuiltByBit للحصول على معلومات المورد والتوثيق بالكامل.",
    },
  },
  {
    id: "zxteams",
    name: "ZxTeams",
    slot: "04",
    link: "https://builtbybit.com/resources/zxteams.131109/",
    image: zxteams,
    description: {
      en: "Published on BuiltByBit as part of my Minecraft project collection. The official resource page has the latest details and requirements.",
      ar: "منشورة على BuiltByBit ضمن مجموعة مشاريع ماينكرافت. تحتوي صفحة المورد الرسمية على أحدث التفاصيل والمتطلبات.",
    },
  },
];

export const PROFILE = {
  name: "Dev zSpeeDx",
  discordUrl: "https://discord.com/users/1515133798289903718",
  discordId: "1515133798289903718",
  builtByBit: "https://builtbybit.com/",
  avatar: profileZ,
};
