import raven from "@/assets/servers/raven.webp";
import rune from "@/assets/servers/rune.webp";
import alpha from "@/assets/servers/alpha.webp";
import phantom from "@/assets/servers/phantom.webp";
import bloodmc from "@/assets/servers/bloodmc.webp";
import alaska from "@/assets/servers/alaska.webp";

export type Server = {
  id: string;
  name: string;
  image: string;
  tone: "red" | "cyan" | "ice" | "violet" | "ember" | "blue";
};

/** Servers supplied by the owner. No extra claims or metrics are attached. */
export const SERVERS: Server[] = [
  { id: "raven", name: "Raven Network", image: raven, tone: "red" },
  { id: "rune", name: "Rune Network", image: rune, tone: "cyan" },
  { id: "alpha", name: "Alpha Network", image: alpha, tone: "ice" },
  { id: "phantom", name: "Phantom Network", image: phantom, tone: "violet" },
  { id: "bloodmc", name: "Blood MC", image: bloodmc, tone: "ember" },
  { id: "alaska", name: "Alaska Network", image: alaska, tone: "blue" },
];
