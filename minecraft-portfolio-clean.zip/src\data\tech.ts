export type TechItem = {
  name: string;
  desc: { en: string; ar: string };
};

export type TechGroup = {
  id: "systems" | "cores" | "network" | "data";
  label: { en: string; ar: string };
  items: TechItem[];
};

/** Platforms and systems explicitly listed by Dev zSpeeDx. */
export const TECH_GROUPS: TechGroup[] = [
  {
    id: "systems",
    label: { en: "Server systems", ar: "أنظمة السيرفر" },
    items: [
      { name: "Custom Systems", desc: { en: "Simple to advanced server systems", ar: "أنظمة سيرفر من البسيط إلى المتقدّم" } },
      { name: "Ranks & Permissions", desc: { en: "Rank ladders, nodes & staff tools", ar: "سلاسل رتب وصلاحيات وأدوات إدارة" } },
      { name: "NPCs & Holograms", desc: { en: "Interactive NPCs and holograms", ar: "شخصيات تفاعلية وهولوغرامات" } },
      { name: "Game Modes", desc: { en: "Survival, BoxPvP, SMP & Duels", ar: "Survival وBoxPvP وSMP وDuels" } },
      { name: "Performance", desc: { en: "Profiling, tuning & async systems", ar: "تحليل وضبط وعمل غير متزامن" } },
      { name: "Community Setup", desc: { en: "Full server & Discord launch setup", ar: "تجهيز سيرفر وديسكورد كامل للافتتاح" } },
    ],
  },
  {
    id: "cores",
    label: { en: "Server platforms", ar: "منصّات السيرفر" },
    items: [
      { name: "Paper", desc: { en: "Plugin development & testing", ar: "تطوير واختبار الإضافات" } },
      { name: "Purpur", desc: { en: "Plugin development & testing", ar: "تطوير واختبار الإضافات" } },
      { name: "Folia", desc: { en: "Regionised multi-threaded Paper", ar: "Paper متعدد الخيوط بنظام المناطق" } },
      { name: "Canvas", desc: { en: "Plugin development & testing", ar: "تطوير واختبار الإضافات" } },
      { name: "Leaf", desc: { en: "Plugin development & testing", ar: "تطوير واختبار الإضافات" } },
    ],
  },
  {
    id: "network",
    label: { en: "Networking & proxy", ar: "الشبكات والبروكسي" },
    items: [
      { name: "Velocity", desc: { en: "Modern Minecraft proxy", ar: "بروكسي حديث لماينكرافت" } },
      { name: "Proxy", desc: { en: "Proxy-side systems & setup", ar: "أنظمة وإعدادات البروكسي" } },
    ],
  },
  {
    id: "data",
    label: { en: "Databases & cache", ar: "قواعد البيانات والتخزين المؤقت" },
    items: [
      { name: "MySQL", desc: { en: "Relational database storage", ar: "تخزين في قاعدة بيانات علائقية" } },
      { name: "MariaDB", desc: { en: "MySQL-compatible database", ar: "قاعدة بيانات متوافقة مع MySQL" } },
      { name: "SQLite", desc: { en: "Lightweight local storage", ar: "تخزين محلي خفيف" } },
      { name: "Redis", desc: { en: "In-memory cache & messaging", ar: "تخزين مؤقت ومراسلة في الذاكرة" } },
    ],
  },
];

export const TECH_NAMES = TECH_GROUPS.flatMap((group) => group.items.map((item) => item.name));
