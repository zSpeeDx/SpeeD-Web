import { useEffect, useRef } from "react";

type TiltOptions = {
  /** Maximum rotation in degrees on each axis. */
  max?: number;
};

/**
 * Pointer tilt + spotlight for a single card. Listeners are attached per card,
 * writes are batched in one rAF, and no React state is involved. Disabled for
 * touch devices and reduced-motion users.
 */
export function useTilt<T extends HTMLElement = HTMLDivElement>({ max = 5 }: TiltOptions = {}) {
  const ref = useRef<T | null>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let frame = 0;
    let rect = element.getBoundingClientRect();
    let px = 0;
    let py = 0;

    const apply = () => {
      frame = 0;
      const nx = rect.width ? Math.min(1, Math.max(0, (px - rect.left) / rect.width)) : 0.5;
      const ny = rect.height ? Math.min(1, Math.max(0, (py - rect.top) / rect.height)) : 0.5;
      element.style.setProperty("--ry", `${((nx - 0.5) * max * 2).toFixed(2)}deg`);
      element.style.setProperty("--rx", `${((ny - 0.5) * -max * 2).toFixed(2)}deg`);
      element.style.setProperty("--gx", `${(nx * 100).toFixed(1)}%`);
      element.style.setProperty("--gy", `${(ny * 100).toFixed(1)}%`);
    };

    const onEnter = () => {
      rect = element.getBoundingClientRect();
      element.setAttribute("data-tilting", "true");
    };

    const onMove = (event: PointerEvent) => {
      px = event.clientX;
      py = event.clientY;
      if (!frame) frame = requestAnimationFrame(apply);
    };

    const onLeave = () => {
      if (frame) {
        cancelAnimationFrame(frame);
        frame = 0;
      }
      element.removeAttribute("data-tilting");
      element.style.removeProperty("--rx");
      element.style.removeProperty("--ry");
      element.style.removeProperty("--gx");
      element.style.removeProperty("--gy");
    };

    element.addEventListener("pointerenter", onEnter);
    element.addEventListener("pointermove", onMove, { passive: true });
    element.addEventListener("pointerleave", onLeave);

    return () => {
      element.removeEventListener("pointerenter", onEnter);
      element.removeEventListener("pointermove", onMove);
      element.removeEventListener("pointerleave", onLeave);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [max]);

  return ref;
}
