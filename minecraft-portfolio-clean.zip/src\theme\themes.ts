export type Theme = {
  id: string;
  hex: string;
  name: { en: string; ar: string };
};

export const THEMES: Theme[] = [
  { id: "red", hex: "#ff0040", name: { en: "Crimson", ar: "قرمزي" } },
  { id: "blue", hex: "#3b82f6", name: { en: "Blue", ar: "أزرق" } },
  { id: "yellow", hex: "#f5c518", name: { en: "Yellow", ar: "أصفر" } },
  { id: "green", hex: "#3fbf5f", name: { en: "Green", ar: "أخضر" } },
  { id: "purple", hex: "#a855f7", name: { en: "Purple", ar: "بنفسجي" } },
  { id: "rose", hex: "#fb7185", name: { en: "Rose", ar: "وردي" } },
  { id: "gold", hex: "#d9a521", name: { en: "Gold", ar: "ذهبي" } },
  { id: "cyan", hex: "#22d3ee", name: { en: "Cyan", ar: "سماوي" } },
  { id: "orange", hex: "#f97316", name: { en: "Orange", ar: "برتقالي" } },
  { id: "emerald", hex: "#10b981", name: { en: "Emerald", ar: "زمردي" } },
  { id: "pink", hex: "#ec4899", name: { en: "Pink", ar: "زهري" } },
  { id: "teal", hex: "#2dd4bf", name: { en: "Teal", ar: "فيروزي" } },
  { id: "lime", hex: "#a3e635", name: { en: "Lime", ar: "ليموني" } },
  { id: "ice", hex: "#93c5fd", name: { en: "Ice", ar: "ثلجي" } },
];

export const DEFAULT_THEME = "red";
export const CUSTOM_THEME_ID = "custom";

export const HEX_PATTERN = /^#?([0-9a-fA-F]{6})$/;

export function normalizeHex(value: string): string | null {
  const match = HEX_PATTERN.exec(value.trim());
  return match ? `#${match[1].toLowerCase()}` : null;
}

export function isValidHex(value: string): boolean {
  return normalizeHex(value) !== null;
}

export function makeCustomTheme(hex: string): Theme {
  const normalized = normalizeHex(hex) ?? "#ff0040";
  return {
    id: CUSTOM_THEME_ID,
    hex: normalized,
    name: { en: "Custom", ar: "مخصص" },
  };
}

export function hexToRgb(hex: string): string {
  const clean = hex.replace("#", "");
  const full =
    clean.length === 3
      ? clean
          .split("")
          .map((c) => c + c)
          .join("")
      : clean;
  const n = Number.parseInt(full, 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

export function getTheme(id: string): Theme {
  return THEMES.find((theme) => theme.id === id) ?? THEMES[0];
}

function isLight(hex: string): boolean {
  const [r, g, b] = hexToRgb(hex).split(" ").map(Number);
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.62;
}

export function applyTheme(theme: Theme) {
  const root = document.documentElement;
  root.style.setProperty("--c", theme.hex);
  root.style.setProperty("--c-rgb", hexToRgb(theme.hex));
  root.style.setProperty("--c-on", isLight(theme.hex) ? "#0b0c0f" : "#ffffff");
  root.setAttribute("data-theme", theme.id);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", "#08090c");
}
